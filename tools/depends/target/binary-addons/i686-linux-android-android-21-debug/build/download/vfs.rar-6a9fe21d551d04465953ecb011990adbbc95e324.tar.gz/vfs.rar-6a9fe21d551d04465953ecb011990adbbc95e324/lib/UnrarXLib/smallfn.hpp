#ifndef _RAR_SMALLFN_
#define _RAR_SMALLFN_

int ToPercent(Int64 N1,Int64 N2);
void RARInitData();

#endif

   UnrarX Manual
    ~~~~~~~~~~~~~

UnrarX is a XBOX port of the UnRAR utility by Eugene Roshal, from
http://www.rarlab.com/rar_add.htm.
It provided an easy interface for extracting RAR files. The interface
is an adaptation of the interface provided in UniquE RAR File Library
(http://www.unrarlib.org/).

The interface is in UnrarX.hpp. It includes a function to list the
contents of the archive (and a companion to free the archive list 
structure),
and another funtion to uncompress. See the comments in the header file
for more info.

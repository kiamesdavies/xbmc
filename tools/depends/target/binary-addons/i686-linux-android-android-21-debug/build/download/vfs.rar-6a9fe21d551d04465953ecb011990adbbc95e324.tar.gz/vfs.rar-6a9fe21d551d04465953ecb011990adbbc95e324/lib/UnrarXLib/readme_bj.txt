MXM's version of UnRar Lib by BenJeremy

One line might need to be commented out - the "E" option line in the
unrar code. That's the one that lets me extract per file and ignore
original pathing.

It's in VS.NET 2003 vproj format for the 5558 XDK. 

PS! UNZIP seems to be hosed. Don't know what's happening there at all. 

BenJeremy

Credits to unleashx who originaly ported it from Unrar utility 3.3.6
see X-S forum: http://forums.xbox-scene.com/index.php?showtopic=200415

Unrar utility by Eugene Roshal
http://www.rarlab.com/rar_add.htm

interface is a adaptation of the one provided in UniquE RAR File Library
http://www.unrarlib.org/

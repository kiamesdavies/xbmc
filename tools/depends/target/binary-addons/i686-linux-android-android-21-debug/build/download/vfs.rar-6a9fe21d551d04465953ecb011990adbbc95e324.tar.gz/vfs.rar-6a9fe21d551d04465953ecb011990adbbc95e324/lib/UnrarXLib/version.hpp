#define RARVER_MAJOR     3
#define RARVER_MINOR    51
#define RARVER_BETA      0
#define RARVER_DAY       4
#define RARVER_MONTH    10
#define RARVER_YEAR   2005
